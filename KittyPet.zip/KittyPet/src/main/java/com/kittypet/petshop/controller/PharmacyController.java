package com.kittypet.petshop.controller;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kittypet.petshop.model.Pharmacy;
import com.kittypet.petshop.service.PharmacyService;


@CrossOrigin("*")
@RestController
@RequestMapping("/pharmacy")
public class PharmacyController {

	@Autowired
	PharmacyService pharmacyService;
	
	
	@PostMapping
	public ResponseEntity<Pharmacy> createMedicine(@RequestBody Pharmacy medicine) {
		return pharmacyService.createMedicine(medicine);
	}
	
	@GetMapping( params = {"type"} )
	public ResponseEntity<List<Pharmacy>> getProductsByTypeAndPet(@RequestParam String type) {
		return pharmacyService.getMedicineByType(type);
	}
	
//	@GetMapping( params = {"type"} )
//	public ResponseEntity<Map<String, Object>>  getProductsByType(
//			@RequestParam(name = "pageNo", defaultValue = "0") int pageNo, 
//    		@RequestParam(name = "pageSize", defaultValue = "2") int pageSize, 
//    		@RequestParam(name = "sortBy", defaultValue = "id") String sortBy,
//			@RequestParam String searchText) {
//		return pharmacyService.getSearchMedicine(pageNo, pageSize, sortBy, searchText);
//	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Pharmacy> getMedicineById(@PathVariable String id) {
		return pharmacyService.getMedicineById(id);
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Pharmacy> updateMedicineById(@RequestBody Pharmacy medicine, @PathVariable String id) {
		return pharmacyService.updateMedicineById(id, medicine);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteMedicineById(@PathVariable String id) {
		return pharmacyService.deleteMedicineById(id);
	}
	
	@GetMapping("/page")
    public ResponseEntity<Map<String, Object>> getAllMedicineInPage(
    		@RequestParam(name = "pageNo", defaultValue = "0") int pageNo, 
    		@RequestParam(name = "pageSize", defaultValue = "2") int pageSize, 
    		@RequestParam(name = "sortBy", defaultValue = "id") String sortBy) {
		return pharmacyService.getAllMedicineInPage(pageNo, pageSize, sortBy);
	}
	
	@GetMapping( params = {"searchText"} )
	public ResponseEntity<Map<String, Object>>  getSearchMedicine(
			@RequestParam(name = "pageNo", defaultValue = "0") int pageNo, 
    		@RequestParam(name = "pageSize", defaultValue = "2") int pageSize, 
    		@RequestParam(name = "sortBy", defaultValue = "id") String sortBy,
			@RequestParam String searchText) {
		return pharmacyService.getSearchMedicine(pageNo, pageSize, sortBy, searchText);
	}
	



}
