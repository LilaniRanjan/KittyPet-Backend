package com.kittypet.petshop.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kittypet.petshop.model.Thing;
import com.kittypet.petshop.service.ThingService;

@RestController
@RequestMapping("/petProducts")
public class ThingController {
	@Autowired
	ThingService thingsService;
	
	@PostMapping
	public ResponseEntity<Thing> createPetProducts(@RequestBody Thing thing) {
		return thingsService.createPetProducts(thing);
	}
	
	@GetMapping
    public ResponseEntity<List<Thing>> getAllThings() {
		return thingsService.getAllThings();
	}
	
	@GetMapping( params = {"type", "pet"} )
	public ResponseEntity<List<Thing>> getProductsByTypeAndPet(@RequestParam String type, 
			@RequestParam String pet) {
		return thingsService.getProductsByTypeAndPet(type, pet);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Thing> getProductById(@PathVariable String id) {
		return thingsService.getProductById(id);
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Thing> updateProduct(@RequestBody Thing things, @PathVariable String id) {
		return thingsService.updateProduct(id, things);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteProductById(@PathVariable String id) {
		return thingsService.deleteProductById(id);
	}
	
	@GetMapping("/page")
    public ResponseEntity<Map<String, Object>> getAllThingsInPage(
    		@RequestParam(name = "pageNo", defaultValue = "0") int pageNo, 
    		@RequestParam(name = "pageSize", defaultValue = "2") int pageSize, 
    		@RequestParam(name = "sortBy", defaultValue = "id") String sortBy) {
		return thingsService.getAllThingsInPage(pageNo, pageSize, sortBy);
	}
	
	@GetMapping( params = {"searchText"} )
	public ResponseEntity<Map<String, Object>>  getSearchThings(
			@RequestParam(name = "pageNo", defaultValue = "0") int pageNo, 
    		@RequestParam(name = "pageSize", defaultValue = "2") int pageSize, 
    		@RequestParam(name = "sortBy", defaultValue = "id") String sortBy,
			@RequestParam String searchText) {
		return thingsService.getSearchThings(pageNo, pageSize, sortBy, searchText);
	}


}
