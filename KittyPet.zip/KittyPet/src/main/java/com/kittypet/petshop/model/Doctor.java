package com.kittypet.petshop.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Doctors")
public class Doctor {
	@Id
	private String id;
	private String name;
	private String address;
	private String contactNumber;
	private String position;
	private String avatarUrl;
	private String type;
	
	public Doctor(String id, String name, String address, String contactNumber, String position, String avatarUrl,
			String type) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.contactNumber = contactNumber;
		this.position = position;
		this.avatarUrl = avatarUrl;
		this.type = type;
	}

	

	public String getId() {
		return id;
	}



	public void setId(String id) {
		this.id = id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public String getContactNumber() {
		return contactNumber;
	}



	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}



	public String getPosition() {
		return position;
	}



	public void setPosition(String position) {
		this.position = position;
	}



	public String getAvatarUrl() {
		return avatarUrl;
	}



	public void setAvatarUrl(String avatarUrl) {
		this.avatarUrl = avatarUrl;
	}



	public String getType() {
		return type;
	}



	public void setType(String type) {
		this.type = type;
	}



	@Override
	public String toString() {
		return "Doctor [id=" + id + ", name=" + name + ", Address=" + address + ", contactNumber=" + contactNumber
				+ ", position=" + position + ", avatarUrl=" + avatarUrl + ", type=" + type + "]";
	}
}
