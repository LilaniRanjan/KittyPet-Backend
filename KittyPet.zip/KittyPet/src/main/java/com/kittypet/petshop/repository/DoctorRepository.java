package com.kittypet.petshop.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.kittypet.petshop.model.Doctor;

@Repository
public interface DoctorRepository extends MongoRepository<Doctor, String>{
	
    List<Doctor> findByType(String type);

}
