package com.kittypet.petshop.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.kittypet.petshop.model.Doctor;
import com.kittypet.petshop.repository.DoctorRepository;

@Service
public class DoctorService {
	@Autowired
	DoctorRepository doctorRepository;
	
	public ResponseEntity<Doctor> createNewDoctor(Doctor doctors) {
		try {
			Doctor med = doctorRepository.insert(doctors);
			return new ResponseEntity<>(med, HttpStatus.CREATED);
		}catch (Exception e) {
			return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	public ResponseEntity<List<Doctor>> getDoctorDetailsByType(String type) {
		try {
			 System.out.println(type);
		    List<Doctor> doc = doctorRepository.findByType(type);
		    System.out.println(doc);
		    if (doc.isEmpty()) {
		      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		    }
		
		    return new ResponseEntity<>(doc, HttpStatus.OK);
		} catch (Exception e) {
		    return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	public ResponseEntity<Doctor> updateDoctorDetailsById(String id, Doctor doctor) {
		Optional<Doctor> oldDoctorDetails= doctorRepository.findById(id);
		if(oldDoctorDetails.isPresent()) {
			Doctor doct= oldDoctorDetails.get();
			doct.setName(doctor.getName());
			doct.setAddress(doctor.getAddress());
			doct.setContactNumber(doctor.getContactNumber());
			doct.setPosition(doctor.getPosition());
			doct.setAvatarUrl(doctor.getAvatarUrl());
			doct.setType(doctor.getType());
		
			return new ResponseEntity<> ((doctorRepository.save(doct)), HttpStatus.OK);
		}else {
			return new ResponseEntity<> (HttpStatus.NOT_FOUND);
		}
	}
	
	public ResponseEntity<String> deleteDoctorsDetailsById(String id) {
		try {
			doctorRepository.deleteById(id); 
			return new ResponseEntity<> ("Successfully deleted", HttpStatus.OK) ; 
		} catch (Exception e) {
			return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}


}
