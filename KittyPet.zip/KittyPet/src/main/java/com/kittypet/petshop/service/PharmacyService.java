package com.kittypet.petshop.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.kittypet.petshop.model.Pharmacy;
import com.kittypet.petshop.model.Thing;
import com.kittypet.petshop.repository.PharmacyRepository;



@Service
public class PharmacyService {
	@Autowired
	PharmacyRepository pharmacyRepository;
	
	public ResponseEntity<Pharmacy> createMedicine(Pharmacy medicine) {
		try {
			Pharmacy med = pharmacyRepository.insert(medicine);
			return new ResponseEntity<>(med, HttpStatus.CREATED);
		}catch (Exception e) {
			return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	public ResponseEntity<List<Pharmacy>> getMedicineByType(String type) {
		try {
		    List<Pharmacy> medicine = pharmacyRepository.findMedicineByType(type);
		
		    if (medicine.isEmpty()) {
		      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		    }
		
		    return new ResponseEntity<>(medicine, HttpStatus.OK);
		} catch (Exception e) {
		    return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
//	public ResponseEntity<Map<String, Object>>  getProductsByTypeAndPet(int pageNo, int pageSize, String sortBy, String type) {
//		try {
//			Map<String, Object> response = new HashMap<>();
//			Sort sort = Sort.by(sortBy);
//			Pageable pageable = PageRequest.of(pageNo, pageSize, sort);
//		    Page<Pharmacy> page =pharmacyRepository.searchMedicine( pageable, type);
//		    response.put("data", page.getContent());
//		    response.put("Total no of pages", page.getTotalPages());
//		    response.put("Total no of elements", page.getTotalElements());
//		    response.put("Current page no", page.getNumber());
//		    
//		    if (page.isEmpty()) {
//		      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
//		    }else {
//		    return new ResponseEntity<>(response, HttpStatus.OK);
//		    }
//		
//		} catch (Exception e) {
//		    return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//	}
	
	
	public ResponseEntity<Pharmacy> getMedicineById(String id) {
		Optional<Pharmacy> med = pharmacyRepository.findById(id) ;
		if(med.isPresent()) {
			return new ResponseEntity<Pharmacy>(med.get(), HttpStatus.OK);
		}else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	public ResponseEntity<Pharmacy> updateMedicineById(String id, Pharmacy newMedicine) {
		Optional<Pharmacy> oldMedicine= pharmacyRepository.findById(id);
		if(oldMedicine.isPresent()) {
			Pharmacy med= oldMedicine.get();
			med.setTitle(newMedicine.getTitle());
			med.setPrice(newMedicine.getPrice());
			med.setDescription(newMedicine.getDescription());
			med.setAvatarUrl(newMedicine.getAvatarUrl());
			med.setImageUrl(newMedicine.getImageUrl());
			med.setType(newMedicine.getType());
		
			return new ResponseEntity<> ((pharmacyRepository.save(med)), HttpStatus.OK);
		}else {
			return new ResponseEntity<> (HttpStatus.NOT_FOUND);
		}
	}
	
	public ResponseEntity<String> deleteMedicineById(String id) {
		try {
			pharmacyRepository.deleteById(id); 
			return new ResponseEntity<> ("Successfully deleted", HttpStatus.OK) ; 
		} catch (Exception e) {
			return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	public ResponseEntity<Map<String, Object>> getAllMedicineInPage(int pageNo, int pageSize, String sortBy) {
		try {
			Map<String, Object> response = new HashMap<>();
		    Sort sort = Sort.by(sortBy);
			Pageable pageable = PageRequest.of(pageNo, pageSize, sort);
		    Page<Pharmacy> page = pharmacyRepository.findAll(pageable);
		    response.put("data", page.getContent());
		    response.put("Total no of pages", page.getTotalPages());
		    response.put("Total no of elements", page.getTotalElements());
		    response.put("Current page no", page.getNumber());
		    
		    return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (Exception e) {
		    return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	public ResponseEntity<Map<String, Object>>  getSearchMedicine(int pageNo, int pageSize, String sortBy, String searchText) {
		try {
			Map<String, Object> response = new HashMap<>();
			Sort sort = Sort.by(sortBy);
			Pageable pageable = PageRequest.of(pageNo, pageSize, sort);
		    Page<Pharmacy> page =pharmacyRepository.searchMedicine( pageable, searchText);
		    response.put("data", page.getContent());
		    response.put("Total no of pages", page.getTotalPages());
		    response.put("Total no of elements", page.getTotalElements());
		    response.put("Current page no", page.getNumber());
		    
		    if (page.isEmpty()) {
		      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		    }else {
		    return new ResponseEntity<>(response, HttpStatus.OK);
		    }
		
		} catch (Exception e) {
		    return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	


}
