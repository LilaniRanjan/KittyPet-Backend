package com.kittypet.petshop.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.kittypet.petshop.model.Pharmacy;
import com.kittypet.petshop.model.Thing;
import com.kittypet.petshop.repository.ThingRepository;

@Service
public class ThingService {
	@Autowired
	ThingRepository thingsRepository;

	public ResponseEntity<Thing> createPetProducts(Thing thing) {
		try {
			Thing product = thingsRepository.insert(thing);
			return new ResponseEntity<>(product, HttpStatus.CREATED);
		}catch (Exception e) {
			return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	public ResponseEntity<List<Thing>> getAllThings() {
		try {
		    List<Thing> thing = new ArrayList<Thing>();
		
		    thingsRepository.findAll().forEach(thing::add);
		
		    if (thing.isEmpty()) {
		      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		    }
		
		    return new ResponseEntity<>(thing, HttpStatus.OK);
		} catch (Exception e) {
		    return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public ResponseEntity<List<Thing>> getProductsByTypeAndPet(String type, String pet) {
		try {
		    List<Thing> product = thingsRepository.findPetProductsByTypeAndPet(type, pet);
		
		    if (product.isEmpty()) {
		      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		    }
		
		    return new ResponseEntity<>(product, HttpStatus.OK);
		} catch (Exception e) {
		    return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	public ResponseEntity<Thing> getProductById(String id) {
		Optional<Thing> product = thingsRepository.findById(id) ;
		if(product.isPresent()) {
			return new ResponseEntity<Thing>(product.get(), HttpStatus.OK);
		}else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	public ResponseEntity<Thing> updateProduct(String id, Thing newThings) {
		Optional<Thing> oldProduct= thingsRepository.findById(id);
		if(oldProduct.isPresent()) {
			Thing product= oldProduct.get();
			product.setTitle(newThings.getTitle());
			product.setImageUrl(newThings.getImageUrl());
			product.setDescription(newThings.getDescription());
			product.setOwner(newThings.getOwner());
			product.setPrice(newThings.getPrice());
			product.setType(newThings.getType());
			product.setPet(newThings.getPet());
		
			return new ResponseEntity<> ((thingsRepository.save(product)), HttpStatus.OK);
		}else {
			return new ResponseEntity<> (HttpStatus.NOT_FOUND);
		}
	}
	
	public ResponseEntity<String> deleteProductById(String id) {
		try {
			thingsRepository.deleteById(id); 
			return new ResponseEntity<> ("Successfully deleted", HttpStatus.OK) ; 
		} catch (Exception e) {
			return new ResponseEntity<> (HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	public ResponseEntity<Map<String, Object>> getAllThingsInPage(int pageNo, int pageSize, String sortBy) {
		try {
			Map<String, Object> response = new HashMap<>();
		    Sort sort = Sort.by(sortBy);
			Pageable pageable = PageRequest.of(pageNo, pageSize, sort);
		    Page<Thing> page = thingsRepository.findAll(pageable);
		    response.put("data", page.getContent());
		    response.put("Total no of pages", page.getTotalPages());
		    response.put("Total no of elements", page.getTotalElements());
		    response.put("Current page no", page.getNumber());
		    
		    return new ResponseEntity<>(response, HttpStatus.OK);
		} catch (Exception e) {
		    return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	public ResponseEntity<Map<String, Object>>  getSearchThings(int pageNo, int pageSize, String sortBy, String searchText) {
		try {
			Map<String, Object> response = new HashMap<>();
			Sort sort = Sort.by(sortBy);
			Pageable pageable = PageRequest.of(pageNo, pageSize, sort);
		    Page<Thing> page =thingsRepository.searchThings( pageable, searchText);
		    response.put("data", page.getContent());
		    response.put("Total no of pages", page.getTotalPages());
		    response.put("Total no of elements", page.getTotalElements());
		    response.put("Current page no", page.getNumber());
		    
		    if (page.isEmpty()) {
		      return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		    }else {
		    return new ResponseEntity<>(response, HttpStatus.OK);
		    }
		
		} catch (Exception e) {
		    return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
