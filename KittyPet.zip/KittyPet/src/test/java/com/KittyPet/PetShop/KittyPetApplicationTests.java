package com.KittyPet.PetShop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KittyPetApplicationTests {

	@Test
	void contextLoads() {
	}

}
