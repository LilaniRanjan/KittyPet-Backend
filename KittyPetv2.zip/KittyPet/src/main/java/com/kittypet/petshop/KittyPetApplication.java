package com.kittypet.petshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KittyPetApplication {

	public static void main(String[] args) {
		SpringApplication.run(KittyPetApplication.class, args);
	}

}
