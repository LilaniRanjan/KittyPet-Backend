package com.kittypet.petshop.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kittypet.petshop.model.Doctor;
import com.kittypet.petshop.service.DoctorService;



@RestController
@RequestMapping("/doctors")
public class DoctorController {
	
	@Autowired
	DoctorService doctorService;
	
	@PostMapping
	public ResponseEntity<Doctor> createNewDoctor(@RequestBody Doctor doctors) {
		return doctorService.createNewDoctor(doctors);
	}
	
	@GetMapping( params = {"type"} )
	public ResponseEntity<List<Doctor>> getDoctorDetailsByType(@RequestParam String type) {
		return doctorService.getDoctorDetailsByType(type);
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Doctor> updateDoctorDetailsById(@RequestBody Doctor doctor, @PathVariable String id) {
		return doctorService.updateDoctorDetailsById(id, doctor);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteDoctorsDetailsById(@PathVariable String id) {
		return doctorService.deleteDoctorsDetailsById(id);
	}
	
	

}
