package com.kittypet.petshop.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Things")
public class Thing {
	@Id
	private String id;
	private String title;
	private String imageUrl;
	private String description;
	private String owner;
	private String price;
	private String type;
	private String pet;
	
	public Thing(String id, String title, String imageUrl, String description, String owner, String price,
			String type, String pet) {
		super();
		this.id = id;
		this.title = title;
		this.imageUrl = imageUrl;
		this.description = description;
		this.owner = owner;
		this.price = price;
		this.type = type;
		this.pet = pet;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getPet() {
		return pet;
	}

	public void setPet(String pet) {
		this.pet = pet;
	}
	
	@Override
    public String toString() {
   	 return "products [id=" + id + ", title=" + title + ", imageUrl=" + imageUrl + ", description=" + description + ", owner="
   			 + owner + ", price=" + price + ", type=" + type +  ", pet=" + pet + "]";
    }


}
