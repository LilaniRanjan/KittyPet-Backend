package com.kittypet.petshop.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.kittypet.petshop.model.Pharmacy;



@Repository
public interface PharmacyRepository extends MongoRepository<Pharmacy, String>{
	
	@Query("{'type' : ?0 }") 
    List<Pharmacy> findMedicineByType(String type);
	
	@Query("{$or: [ { 'title': { $regex: ?0 , $options: 'i' } }, {'price':{ $regex: ?0, $options: 'i' } },{ 'description': { $regex:?0 , $options: 'i' } },{ 'type': { $regex: ?0 , $options: 'i' } } ]}")
	Page<Pharmacy> searchMedicine(Pageable pageable, String searchText);

}
