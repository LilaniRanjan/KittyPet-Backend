package com.kittypet.petshop.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.kittypet.petshop.model.Pharmacy;
import com.kittypet.petshop.model.Thing;

@Repository
public interface ThingRepository extends MongoRepository<Thing, String> {
	
	@Query("{'type' : ?0 , 'pet' : ?1}") 
    List<Thing> findPetProductsByTypeAndPet(String type, String pet);
	
	@Query("{$or: [ { 'title': { $regex: ?0 , $options: 'i' } }, {'description':{ $regex: ?0, $options: 'i' } },{ 'owner': { $regex:?0 , $options: 'i' } },{ 'price': { $regex: ?0 , $options: 'i' } } ]},{ 'type': { $regex: ?0 , $options: 'i' } } ]},{ 'pet': { $regex: ?0 , $options: 'i' } } ]}")
	Page<Thing> searchThings(Pageable pageable, String searchText);


}
